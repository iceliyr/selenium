imgUrl1="data/afficheimg/20081027angsif.jpg";
imgtext1="";
imgLink1=escape("http://www.ecshop.com");
imgUrl2="data/afficheimg/20081027xuorxj.jpg";
imgtext2="";
imgLink2=escape("http://www.maifou.net/");

var pics=imgUrl1+"|"+imgUrl2;
var links=imgLink1+"|"+imgLink2;
var texts=imgtext1+"|"+imgtext2;